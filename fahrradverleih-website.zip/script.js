document.querySelector("form").addEventListener("submit", function (e) {
  e.preventDefault();
  alert("Vielen Dank für deine Reservierung!");
});
